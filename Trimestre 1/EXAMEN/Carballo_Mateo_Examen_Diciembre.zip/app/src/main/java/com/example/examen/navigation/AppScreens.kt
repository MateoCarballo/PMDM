package com.example.examen.navigation

enum class AppScreens {
    HOME_SCREEN,
    PRINCIPAL_SCREEN,
    DETAILS_SCREEN
}